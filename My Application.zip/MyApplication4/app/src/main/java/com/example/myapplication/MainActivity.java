package com.example.myapplication;

import android.support.v7.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.ImageView;

public class MainActivity extends AppCompatActivity{

    Button login;
    ImageView imageView2;
    TextView textView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        login = (Button) findViewById(R.id.login);
        textView =(TextView) findViewById(R.id.textView);
        imageView2 =(ImageView) findViewById(R.id.imageView2);
    }
    public void buttonClick (View view) {
        Intent i = new Intent(MainActivity.this, MainActivity2.class);
        MainActivity.this.startActivity(i);

    }

}